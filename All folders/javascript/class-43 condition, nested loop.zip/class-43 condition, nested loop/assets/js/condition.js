let x = 10;
if (x > 5) {
    console.log("greter than");
    document.write("true");
} else if(x < 5) {
    console.log("less than");
    document.write("<br> false");
}else{
    console.log("equal");
    document.write("<br> equal");
}

let date = 30;
date = 31;
if(date >= 1 && data <= 31){
    switch (date) {
        case 1:
            console.log("Start of month");
            break;
        case 30:
            console.log("End of month");
            break;
        case 31:
            console.log("End of month");
            break;
        default:
            console.log("Middle of month");
            break;
    }    
}
