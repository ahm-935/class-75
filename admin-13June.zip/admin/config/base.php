<?php
    // Localhost
    const BASE_URL = 'http://localhost/php-project-adminltee/php-project/';
    const BASE_URL_ADMIN = 'http://localhost/php-project-adminltee/php-project/admin/';

    // Hosting
    // const BASE_URL = 'https://yourdomain.com/';
    // const BASE_URL_ADMIN = 'https://yourdomain.com/admin/';
?>