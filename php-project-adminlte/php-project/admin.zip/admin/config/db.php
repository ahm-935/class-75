<?php
//localhost
const DB_HOST = 'localhost';
const DB_USER = 'root';
const DB_PASSWORD = '';
const DB_NAME = 'ecom';


//Hosting
// const DB_HOST = 'localhost';
// const DB_USER = 'root';
// const DB_PASSWORD = '';
// const DB_NAME = 'php_project';


?>