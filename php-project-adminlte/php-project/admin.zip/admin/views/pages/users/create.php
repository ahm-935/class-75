<?php
require_once 'models/user.class.php';

if (isset($_POST['btn_submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $role_id = $_POST['role_id'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if ($password == $confirm_password) {
        $password = password_hash($password, PASSWORD_DEFAULT);
        $user = new User(null, $name, $email, $role_id, $password);
        $res = $user->create();
        if ($res === true) {
            $msg =  "User created successfully.";
        } else {
            $msg = $res;
        }
    } else {
        $msg = "Passwords do not match.";
    }
}
?>

<div class="col-md-6">
                    <div class="row">
                        <div class="col-md-12">
                            <h4><?= $msg ?? "" ?></h4>
                            <div class="card card-primary card-outline mb-4">
                                <div class="card-header">
                                    <div class="card-title">Create User</div>
                                </div>
                                <form>
                                    <div class="card-body">
                                        <div class="mb-3">
                                            <label for="Name" class="form-label">Name</label>
                                            <input type="text" class="form-control" name="name" id="name" aria-describedby="">
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleInputEmail1" class="form-label">Email address</label>
                                            <input type="email" class="form-control" name="email" id="exampleInputEmail1" aria-describedby="emailHelp">
                                            <div id="emailHelp" class="form-text">
                                                We'll never share your email with anyone else.
                                            </div>
                                        </div>
                                        <div class="form-group"> 
                                            <label for="exampleInputEmail1" class="form-label">Role</label>
                                            <select class="form-control" name="role" name="role_id" aria-label="Default select example">
                                                <option selected>Open this select menu</option>
                                                <option value="1">Admin</option>
                                                <option value="2">User</option>
                                            </select>

                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleInputPassword1" class="form-label">Password</label>
                                            <input type="password" class="form-control" name="password" id="exampleInputPassword1">
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleInputPassword1" class="form-label">Confirm Password</label>
                                            <input type="password" class="form-control" name="confirm_password" id="exampleInputPassword1">
                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <button type="submit" name="btn_submit" class="btn btn-primary">Submit</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>