 <?php
require_once 'models/user.class.php';
$rows = User::readAll();
echo '<pre>';
print_r($rows);
echo '</pre>';
 ?>
 <!--begin::App Wrapper-->
 <div class="app-wrapper">
     <!--begin::Header-->
     <!-- nav -->
     <!--end::Header-->
     <!--begin::Sidebar-->

     <!--end::Sidebar-->
     <!--begin::App Main-->
     <main class="app-main">
         <!--begin::App Content Header-->
         <div class="app-content-header">
             <!--begin::Container-->
             <div class="container-fluid">
                 <!--begin::Row-->
                 <div class="row">
                     <div class="col-sm-6">
                         <h3 class="mb-0">Simple Tables</h3>
                     </div>
                     <div class="col-sm-6">
                         <ol class="breadcrumb float-sm-end">
                             <li class="breadcrumb-item"><a href="#">Home</a></li>
                             <li class="breadcrumb-item active" aria-current="page">Simple Tables</li>
                         </ol>
                     </div>
                 </div>
                 <!--end::Row-->
             </div>
             <!--end::Container-->
         </div>
         <!--end::App Content Header-->
         <!--begin::App Content-->
         <div class="app-content">
             <!--begin::Container-->
             <div class="container-fluid">
                 <!--begin::Row-->
                 <div class="row">
                     <div class="col-12">
                         <div class="card mb-4">
                             <div class="card-header">
                                 <a href="create-user" class="btn btn-primary">Create User</a>
                             </div>
                             <!-- /.card-header -->
                             <div class="card-body">
                                 <div class="table-responsive">
                                     <table class="table table-bordered">
                                         <thead>
                                             <tr>
                                                 <th style="width: 10px">ID</th>
                                                 <th>Name</th>
                                                 <th>Email</th>
                                                 <th style="width: 40px">Action</th>
                                             </tr>
                                         </thead>
                                         <tbody>
                                            <?php foreach ($rows as $item): ?>
                                             <tr class="align-middle">
                                                 <td><?= $item['id'] ; ?></td>
                                                 <td><?= $item['name'] ; ?></td>
                                                 <td>
                                                     <span class="badge text-bg-primary"><?= $item['email'] ; ?></span>                         </td>
                                                 <td>
                                                     <div class="btn-group">
                                                         <button class="btn btn-sm btn-default"><i class="fa fa-eye text-primary"></i>details</button>
                                                         <button class="btn btn-sm btn-default"><i class="fa fa-edit text-success"></i>edit</button>
                                                         <button class="btn btn-sm btn-default"><i class="fa fa-trash text-danger"></i>Delete</button>
                                                     </div>
                                                 </td>
                                             </tr>
                                             <?php endforeach; ?>
                                         </tbody>
                                     </table>
                                 </div>
                             </div>
                             <!-- /.card-body -->
                            
                         </div>
                         <!-- /.card -->


                         <!-- /.card -->
                     </div>
                     <!-- /.col -->

                     <!-- /.col -->
                 </div>
                 <!--end::Row-->
             </div>
             <!--end::Container-->
         </div>
         <!--end::App Content-->
     </main>
     <!--end::App Main-->
     <!--begin::Footer-->
 </div>
 <!--end::App Wrapper-->